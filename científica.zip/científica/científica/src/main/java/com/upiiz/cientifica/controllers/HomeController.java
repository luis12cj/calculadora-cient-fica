package com.upiiz.cientifica.controllers;

public class HomeController {
}
