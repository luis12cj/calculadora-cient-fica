package com.upiiz.cientifica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CientificaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CientificaApplication.class, args);
	}

}
