package com.upiiz.cientifica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CientificaApplicationTests {

	@Test
	void contextLoads() {
	}

}
